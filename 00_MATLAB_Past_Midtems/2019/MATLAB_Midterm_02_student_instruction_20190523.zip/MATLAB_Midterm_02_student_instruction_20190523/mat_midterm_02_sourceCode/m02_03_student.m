%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Midterm Number: Two
% Problem number: 3
% Student Name:  �
% Student ID: �
% Email address: �
% Department: 
% Date: �.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% close all windows
% clear variables, and clear screen
close all; clf; clear; clc;

% show Lab
disp('Midterm Two')

axis([-10 10 -20 20]);
grid

dx = 0.02;
x = -10:dx:10;


