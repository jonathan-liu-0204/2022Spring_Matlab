%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Midterm Number: �
% Problem number: �
% Student Name:  �
% Student ID: �
% Email address: �
% Department:
% Date: �.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%

close all; clear; clc;		% close all windows
                            % clear variables, and clear screen

disp('Midterm Problem ?.?') 	% show Midterm Problem ?.?

disp('Student Name; Student ID');
