%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Midterm Number: Two
% Problem number: 2
% Student Name:  �
% Student ID: �
% Email address: �
% Department: 
% Date: �.

close all; clf;clear;
I = imread('tmp.png');
I = im2double(I);
I1 = imresize(I,[640 640]);

while true
    disp('0) quit the program');
    disp('1) Shift the image to left');
    disp('2) Shift the image to right');
    disp('3) Shift the image to top');
    disp('4) Shift the image to bottom');
    disp('5) Turn on or off a spot light on the center');
    op = input('Please enter an option:');
    if op==0
        disp('Thanks for playing');
        return;
    end
    
end


